<?php
namespace adminbase\Model\System;

use Cml\Model;

class SystemLogModel extends Model
{
    protected $table = 'admin_systemlog';

}
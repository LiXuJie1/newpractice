<?php
namespace adminbase\Model\System;

use Cml\Model;

class LoginLogModel extends Model
{
    protected $table = 'admin_loginlog';


}
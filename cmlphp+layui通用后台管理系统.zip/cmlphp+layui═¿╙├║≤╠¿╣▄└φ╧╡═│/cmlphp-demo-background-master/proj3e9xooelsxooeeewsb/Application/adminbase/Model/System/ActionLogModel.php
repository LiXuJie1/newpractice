<?php
namespace adminbase\Model\System;

use Cml\Model;

class ActionLogModel extends Model
{
    protected $table = 'admin_actionlog';

   
}
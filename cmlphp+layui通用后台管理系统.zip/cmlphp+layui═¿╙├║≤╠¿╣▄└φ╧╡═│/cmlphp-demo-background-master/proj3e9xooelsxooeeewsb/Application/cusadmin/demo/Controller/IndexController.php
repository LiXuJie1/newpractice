<?php

namespace cusadmin\demo\Controller;

use Cml\Controller;

class IndexController extends Controller
{
    public function index()
    {
        echo '欢迎使用cmlphp';
    }
}
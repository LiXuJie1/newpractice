<?php
//配置文件
defined('CML_PATH') || exit();

return require dirname(__DIR__) . DIRECTORY_SEPARATOR . 'product' . DIRECTORY_SEPARATOR . 'normal.php';